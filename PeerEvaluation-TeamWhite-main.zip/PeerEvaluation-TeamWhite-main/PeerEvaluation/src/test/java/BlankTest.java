import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.*;

/**
 * 
 */

public class BlankTest
{
    @Test
    public void testBlank() 
    {
    	try {
	   
		} 
	
		catch (Exception e) {
	   
		}
    }
}









