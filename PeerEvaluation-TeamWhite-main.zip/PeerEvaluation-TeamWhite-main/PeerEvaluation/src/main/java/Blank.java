/**
 *
 *
 */
import java.io. * ;
import java.util.Scanner;


public class Blank 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello Calculator! AMA." );
    }
    
    // add methods here    
      public static void parseCSV(String[] args) throws Exception {
    Scanner sc = new Scanner(new File("evals.csv"));
    //parsing a CSV file into the constructor of Scanner class 
    sc.useDelimiter(",");
    //setting comma as delimiter pattern
    while (sc.hasNext()) {
      System.out.print(sc.next());
    }
    sc.close();
    //closes the scanner  
  }
}


